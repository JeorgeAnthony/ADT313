import React from 'react';

const StudentInfo = ({ name, course, section }) => {
  return (
    <div>
      <h2>Student Information</h2>
      <p>Name: {name}</p>
      <p>Course: {course}</p>
      <p>Section: {section}</p>
    </div>
  );
};

export default StudentInfo;