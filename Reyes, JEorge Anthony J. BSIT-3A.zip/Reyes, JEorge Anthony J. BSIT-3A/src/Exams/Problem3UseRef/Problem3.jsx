import React, { useRef, useEffect } from 'react';

function Problem3() {
  const inputRefs = useRef([]);

  useEffect(() => {
    const emptyInput = inputRefs.current.find((input) => !input.value);
    if (emptyInput) {
      emptyInput.focus();
    }
  }, []);

  const handleButtonClick = () => {
    const emptyInput = inputRefs.current.find((input) => !input.value);
    if (emptyInput) {
      emptyInput.focus();
    }
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input ref={(input) => (inputRefs.current[0] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input ref={(input) => (inputRefs.current[1] = input)} type='text' />
      </div>
    
      <div style={{ display: 'block' }}>
        Input 10: <input ref={(input) => (inputRefs.current[9] = input)} type='text' />
      </div>
      <button type='button' onClick={handleButtonClick}>I'm a button</button>
    </>
  );
}

export default Problem3;
