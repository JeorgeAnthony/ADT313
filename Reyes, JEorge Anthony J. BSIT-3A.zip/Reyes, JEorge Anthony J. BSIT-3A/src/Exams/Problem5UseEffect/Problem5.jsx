import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isUserTyping, setIsUserTyping] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(timeoutId);
  }, []);

  useEffect(() => {
    const handleTyping = () => {
      setIsUserTyping(true);
    };

    const handleIdle = () => {
      setIsUserTyping(false);
    };

    inputRef.current.addEventListener('keydown', handleTyping);
    inputRef.current.addEventListener('keyup', handleIdle);

    return () => {
      inputRef.current.removeEventListener('keydown', handleTyping);
      inputRef.current.removeEventListener('keyup', handleIdle);
    };
  }, []);

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input ref={inputRef} type="text" />
            <p>User is {isUserTyping ? 'typing' : 'idle'}.</p>
          </div>
        </>
      )}
    </>
  );
}