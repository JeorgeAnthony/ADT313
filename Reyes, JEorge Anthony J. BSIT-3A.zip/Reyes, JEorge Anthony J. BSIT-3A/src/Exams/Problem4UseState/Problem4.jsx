import React, { useState } from 'react';

export default function Problem4() {
  const [formData, setFormData] = useState({
    name: 'Jeorge Reyes',
    yearLevel: '3rd Year',
    course: 'BSIT',
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input type="text" name="name" value={formData.name} onChange={handleChange} />
      </div>
      <div style={{ display: 'block' }}>
        <p>Year Level:</p>
        <input
          type="radio"
          id="firstYear"
          name="yearLevel"
          value="First Year"
          checked={formData.yearLevel === 'First Year'}
          onChange={handleChange}
        />
        <label htmlFor="firstYear">First Year</label>
        <br />
  
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select name="course" value={formData.course} onChange={handleChange}>
          <option value="BSCS">BSCS</option>
          <option value="BSIT">BSIT</option>
          <option value="BSCpE">BSCpE</option>
          <option value="ACT">ACT</option>
        </select>
      </div>
      <p>Form Data:</p>
      <pre>{JSON.stringify(formData, null, 2)}</pre>
    </>
  );
}